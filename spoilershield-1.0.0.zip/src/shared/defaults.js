/*
 * SpoilerShield — default settings and keyword lists.
 *
 * Classic script (no ES modules) so it can be shared by content scripts,
 * the service worker (importScripts), the popup/options pages and Node tests.
 */
(function (root) {
  'use strict';

  const NS = (root.SpoilerShield = root.SpoilerShield || {});

  /**
   * Default keyword categories. Every entry is matched case-insensitively,
   * after Unicode/leetspeak normalisation (see matcher.js), as a whole word
   * or phrase. Multi-word phrases also match their joined hashtag form
   * ("vice city" also matches "#ViceCity"). Entries containing a digit
   * (e.g. "gta 6") additionally match inside run-together text
   * ("gta6trailer", "G.T.A. 6").
   */
  const DEFAULT_CATEGORIES = {
    core: {
      label: 'GTA 6 names & spellings',
      description: 'Title variants, abbreviations, hashtags and common misspellings.',
      keywords: [
        'gta 6', 'gta vi', 'gta six', 'gta6', 'gtavi', 'gta 6 trailer', 'gta vi trailer',
        'grand theft auto 6', 'grand theft auto vi', 'grand theft auto six',
        'grandtheftauto6', 'grandtheftautovi',
        'gta 2026', 'gta 2027', 'gta next', 'next gta', 'new gta', 'gta new',
        'project americas', 'gta vi leak', 'gta 6 leak', 'gta leak', 'gta leaks',
        'gat 6', 'gta 6ix', 'gta sei', 'gta seis', 'gta sechs'
      ]
    },
    characters: {
      label: 'Characters',
      description: 'Protagonists and known characters.',
      keywords: [
        'lucia', 'jason', 'lucia caminos', 'jason duval', 'cal hampton',
        'boobie ike', 'dre quan priest', 'drequan', 'real dimez', 'bae luxe',
        'raul bautista', 'brian heder'
      ]
    },
    places: {
      label: 'Places',
      description: 'In-game locations.',
      keywords: [
        'vice city', 'leonida', 'leonida keys', 'port gellhorn', 'grassrivers',
        'mount kalaga', 'kalaga'
      ]
    },
    spoilerWords: {
      label: 'Spoiler words',
      description: 'Generic plot words. Hides ANY item containing them, GTA-related or not.',
      keywords: ['ending', 'endings', 'death', 'deaths', 'dies']
    },
    broad: {
      label: 'Broad GTA / Rockstar terms',
      description: 'Bare "GTA" and Rockstar mentions. Catches more, including some non-GTA 6 content.',
      keywords: [
        'gta', 'grand theft auto', 'rockstar games', 'rockstar north', 'rockstargames',
        'rockstar trailer', 'take two interactive', 'gta online'
      ]
    }
  };

  const SITES = {
    youtube: { label: 'YouTube' },
    reddit: { label: 'Reddit' },
    x: { label: 'X / Twitter' },
    instagram: { label: 'Instagram' },
    tiktok: { label: 'TikTok' },
    google: { label: 'Google' }
  };

  const DEFAULT_SETTINGS = {
    version: 1,
    enabled: true,
    // 'normal' = hide items whose text matches.
    // 'strict' = items stay hidden until verified; items with too little text
    //            to verify stay hidden; looser (substring) matching.
    mode: 'normal',
    // Strict mode only: cover pages/feeds the site adapter does not recognise.
    failClosed: false,
    sites: Object.fromEntries(Object.keys(SITES).map((k) => [k, true])),
    categories: Object.fromEntries(Object.keys(DEFAULT_CATEGORIES).map((k) => [k, true])),
    customKeywords: [],
    disabledKeywords: []
  };

  /** Merge stored settings over defaults, tolerating missing/old fields. */
  function mergeSettings(stored) {
    const s = stored && typeof stored === 'object' ? stored : {};
    return {
      ...DEFAULT_SETTINGS,
      ...s,
      mode: s.mode === 'strict' ? 'strict' : 'normal',
      enabled: s.enabled !== false,
      failClosed: !!s.failClosed,
      sites: { ...DEFAULT_SETTINGS.sites, ...(s.sites || {}) },
      categories: { ...DEFAULT_SETTINGS.categories, ...(s.categories || {}) },
      customKeywords: Array.isArray(s.customKeywords) ? s.customKeywords.filter((k) => typeof k === 'string') : [],
      disabledKeywords: Array.isArray(s.disabledKeywords) ? s.disabledKeywords.filter((k) => typeof k === 'string') : []
    };
  }

  /**
   * Build the active keyword list from settings.
   * Returns [{ keyword, category }].
   */
  function activeKeywords(settings) {
    const s = mergeSettings(settings);
    const disabled = new Set(s.disabledKeywords.map((k) => k.trim().toLowerCase()));
    const out = [];
    const seen = new Set();
    for (const [cat, def] of Object.entries(DEFAULT_CATEGORIES)) {
      if (!s.categories[cat]) continue;
      for (const kw of def.keywords) {
        const key = kw.toLowerCase();
        if (disabled.has(key) || seen.has(key)) continue;
        seen.add(key);
        out.push({ keyword: kw, category: cat });
      }
    }
    for (const kw of s.customKeywords) {
      const key = kw.trim().toLowerCase();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push({ keyword: kw.trim(), category: 'custom' });
    }
    return out;
  }

  NS.DEFAULT_CATEGORIES = DEFAULT_CATEGORIES;
  NS.DEFAULT_SETTINGS = DEFAULT_SETTINGS;
  NS.SITES = SITES;
  NS.mergeSettings = mergeSettings;
  NS.activeKeywords = activeKeywords;
  NS.STORAGE_KEY = 'settings';
  NS.STATS_KEY = 'stats';
})(typeof globalThis !== 'undefined' ? globalThis : self);
