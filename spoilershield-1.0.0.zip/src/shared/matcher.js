/*
 * SpoilerShield — text normalisation and keyword matching.
 *
 * Pure functions, no DOM, no chrome.* APIs. Everything happens locally.
 *
 * Matching strategy for each keyword (after normalisation of both sides):
 *   1. Whole word / phrase:   " gta 6 " inside " watch the gta 6 trailer "
 *   2. Joined (hashtag) form: "vice city" also matches the token "vicecity"
 *   3. Run-together substring, only for "distinctive" keywords (contain a
 *      digit or non-Latin characters, or are in the "core" title category),
 *      e.g. "gta6" inside "gta6trailerreaction" or "G.T.A. 6".
 *   4. Strict mode adds run-together substring for all keywords of 5+
 *      characters except generic spoiler words ("ending" would otherwise
 *      match "spending").
 * Each check runs on a plain variant and a leetspeak-decoded variant
 * ("Luc1a" -> "lucia", "GT4 V1" -> "gta vi").
 */
(function (root) {
  'use strict';

  const NS = (root.SpoilerShield = root.SpoilerShield || {});

  // Invisible / formatting characters often used to dodge filters.
  const INVISIBLE_RE = /[­͏؜ᅟᅠ឴឵᠎​-‏‪-‮⁠-⁯ㅤ︀-️﻿ﾠ]/g;
  const MARKS_RE = /\p{M}+/gu;
  const NON_WORD_RE = /[^\p{L}\p{N}]+/gu;

  // Common Cyrillic / Greek look-alikes (applied after lower-casing).
  const CONFUSABLES = {
    'а': 'a', 'в': 'b', 'е': 'e', 'ё': 'e', 'к': 'k', 'м': 'm', 'н': 'h', 'о': 'o', 'р': 'p',
    'с': 'c', 'т': 't', 'у': 'y', 'х': 'x', 'і': 'i', 'ї': 'i', 'ј': 'j', 'ѕ': 's', 'ԁ': 'd',
    'ɡ': 'g', 'ı': 'i', 'ʟ': 'l',
    'α': 'a', 'β': 'b', 'ε': 'e', 'η': 'n', 'ι': 'i', 'κ': 'k', 'ν': 'v', 'ο': 'o', 'ρ': 'p',
    'τ': 't', 'υ': 'u', 'χ': 'x', 'ϲ': 'c'
  };
  const CONFUSABLES_RE = new RegExp('[' + Object.keys(CONFUSABLES).join('') + ']', 'g');

  const LEET = { '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '8': 'b', '@': 'a', '$': 's', '!': 'i', '|': 'i', '€': 'e' };
  const LEET_RE = /[0134578@$!|€]/g;

  function baseFold(text) {
    return String(text)
      .normalize('NFKC') // fullwidth, ligatures, Ⅵ -> VI, mathematical alphanumerics
      .toLowerCase()
      .replace(INVISIBLE_RE, '')
      .normalize('NFKD')
      .replace(MARKS_RE, '') // strip accents: Lucía -> lucia
      .replace(CONFUSABLES_RE, (c) => CONFUSABLES[c]);
  }

  function toForms(folded) {
    const spacedCore = folded.replace(NON_WORD_RE, ' ').trim();
    return {
      spaced: ' ' + spacedCore + ' ',
      compact: spacedCore.replace(/ /g, '')
    };
  }

  /**
   * Normalise text into the forms used for matching.
   * @returns {{spaced:string, compact:string, leetSpaced:string, leetCompact:string}}
   */
  function normalize(text) {
    if (text == null) text = '';
    const folded = baseFold(text);
    const plain = toForms(folded);
    const leet = toForms(folded.replace(LEET_RE, (c) => LEET[c]));
    return { spaced: plain.spaced, compact: plain.compact, leetSpaced: leet.spaced, leetCompact: leet.compact };
  }

  function isDistinctive(compact) {
    return /\d/.test(compact) || /[^a-z0-9]/.test(compact);
  }

  /**
   * Compile keyword entries into a matcher.
   * @param {Array<{keyword:string, category:string}|string>} entries
   * @param {{strict?: boolean}} [opts]
   */
  function createMatcher(entries, opts) {
    const strict = !!(opts && opts.strict);
    const compiled = [];
    for (const entry of entries || []) {
      const keyword = typeof entry === 'string' ? entry : entry && entry.keyword;
      const category = (entry && entry.category) || 'custom';
      if (!keyword || !String(keyword).trim()) continue;
      const n = normalize(keyword);
      if (!n.compact) continue;
      const distinctive = isDistinctive(n.compact);
      const substring =
        (n.compact.length >= 4 && (distinctive || category === 'core')) ||
        (strict && category !== 'spoilerWords' && n.compact.length >= 5);
      compiled.push({
        keyword: String(keyword).trim(),
        category,
        variants: [
          { spaced: n.spaced, joined: ' ' + n.compact + ' ', compact: n.compact, leet: false },
          { spaced: n.leetSpaced, joined: ' ' + n.leetCompact + ' ', compact: n.leetCompact, leet: true }
        ],
        substring
      });
    }

    function testNormalized(norm) {
      for (const kw of compiled) {
        for (const v of kw.variants) {
          const spaced = v.leet ? norm.leetSpaced : norm.spaced;
          const compact = v.leet ? norm.leetCompact : norm.compact;
          if (spaced.includes(v.spaced) || spaced.includes(v.joined) || (kw.substring && compact.includes(v.compact))) {
            return { keyword: kw.keyword, category: kw.category };
          }
        }
      }
      return null;
    }

    return {
      size: compiled.length,
      strict,
      /** @returns {null | {keyword:string, category:string}} */
      test(text) {
        if (!text) return null;
        return testNormalized(normalize(text));
      },
      testNormalized
    };
  }

  NS.normalize = normalize;
  NS.createMatcher = createMatcher;
})(typeof globalThis !== 'undefined' ? globalThis : self);
