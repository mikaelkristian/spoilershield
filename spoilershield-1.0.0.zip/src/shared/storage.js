/*
 * SpoilerShield — settings storage. Uses chrome.storage.local only:
 * nothing is synced to a Google account and nothing leaves the device.
 */
(function (root) {
  'use strict';

  const NS = (root.SpoilerShield = root.SpoilerShield || {});

  function storageArea() {
    return root.chrome && root.chrome.storage && root.chrome.storage.local;
  }

  async function loadSettings() {
    const area = storageArea();
    if (!area) return NS.mergeSettings(null);
    const data = await area.get(NS.STORAGE_KEY);
    return NS.mergeSettings(data && data[NS.STORAGE_KEY]);
  }

  async function saveSettings(settings) {
    const merged = NS.mergeSettings(settings);
    await storageArea().set({ [NS.STORAGE_KEY]: merged });
    return merged;
  }

  /** Read-modify-write helper: updater receives a copy and returns the new settings. */
  async function updateSettings(updater) {
    const current = await loadSettings();
    const next = updater(JSON.parse(JSON.stringify(current))) || current;
    return saveSettings(next);
  }

  async function loadStats() {
    const area = storageArea();
    if (!area) return { total: 0, bySite: {} };
    const data = await area.get(NS.STATS_KEY);
    const s = (data && data[NS.STATS_KEY]) || {};
    return { total: s.total || 0, bySite: s.bySite || {} };
  }

  NS.loadSettings = loadSettings;
  NS.saveSettings = saveSettings;
  NS.updateSettings = updateSettings;
  NS.loadStats = loadStats;
})(typeof globalThis !== 'undefined' ? globalThis : self);
