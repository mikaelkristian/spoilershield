/*
 * SpoilerShield — background service worker.
 * Keeps the blocked-item counters and the toolbar badge. No network access.
 */
importScripts('../shared/defaults.js');

const NS = self.SpoilerShield;

chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get([NS.STORAGE_KEY, NS.STATS_KEY]);
  const patch = {};
  if (!data[NS.STORAGE_KEY]) patch[NS.STORAGE_KEY] = NS.mergeSettings(null);
  if (!data[NS.STATS_KEY]) patch[NS.STATS_KEY] = { total: 0, bySite: {} };
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
  chrome.action.setBadgeBackgroundColor({ color: '#2f7d57' });
});

// Serialise read-modify-write of the totals so concurrent tabs never lose counts.
let queue = Promise.resolve();
function addToTotals(site, delta) {
  queue = queue
    .then(async () => {
      const data = await chrome.storage.local.get(NS.STATS_KEY);
      const stats = data[NS.STATS_KEY] || { total: 0, bySite: {} };
      stats.total = (stats.total || 0) + delta;
      stats.bySite = stats.bySite || {};
      stats.bySite[site] = (stats.bySite[site] || 0) + delta;
      await chrome.storage.local.set({ [NS.STATS_KEY]: stats });
    })
    .catch(() => {});
  return queue;
}

function badgeText(n) {
  if (!n) return '';
  return n > 999 ? '999+' : String(n);
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.type !== 'ss-count' || !sender.tab) return;
  const tabId = sender.tab.id;
  if (sender.frameId === 0) {
    chrome.action.setBadgeText({ tabId, text: badgeText(msg.pageCount) }).catch(() => {});
    chrome.storage.session.set({ ['tab:' + tabId]: msg.pageCount }).catch(() => {});
  }
  if (msg.delta > 0) addToTotals(String(msg.site || 'other'), msg.delta);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove('tab:' + tabId).catch(() => {});
});

// Reflect the global on/off switch on the icon.
async function refreshBadgeColor() {
  const data = await chrome.storage.local.get(NS.STORAGE_KEY);
  const s = NS.mergeSettings(data[NS.STORAGE_KEY]);
  chrome.action.setBadgeBackgroundColor({ color: s.enabled ? '#2f7d57' : '#6b7280' });
  chrome.action.setTitle({ title: s.enabled ? 'SpoilerShield (on)' : 'SpoilerShield (off)' });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[NS.STORAGE_KEY]) refreshBadgeColor();
});
refreshBadgeColor();
