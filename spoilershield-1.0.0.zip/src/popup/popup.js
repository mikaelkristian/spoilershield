/* SpoilerShield — toolbar popup. */
(async function () {
  'use strict';
  const NS = globalThis.SpoilerShield;
  const $ = (id) => document.getElementById(id);

  const MODE_HELP = {
    normal: 'Hides posts, cards, videos and comments whose text matches your keywords.',
    strict: 'Also keeps every card hidden until its text has loaded and been checked, hides cards with too little text to check (e.g. image-only), and matches more loosely.'
  };

  let settings = await NS.loadSettings();
  let tab = null;
  let info = null;

  try {
    // ?tab=<id> lets the store-screenshot script point the popup at a specific tab.
    const forcedTab = Number(new URLSearchParams(location.search).get('tab'));
    [tab] = forcedTab ? [{ id: forcedTab }] : await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) info = await chrome.tabs.sendMessage(tab.id, { type: 'ss-page-info' });
  } catch (_) {
    info = null; // no content script here: not a supported site, or page loaded before install
  }

  function render() {
    $('enabled').checked = settings.enabled;
    document.body.classList.toggle('off', !settings.enabled);
    for (const b of document.querySelectorAll('[data-mode]')) {
      b.setAttribute('aria-checked', String(b.dataset.mode === settings.mode));
    }
    $('modeHelp').textContent = MODE_HELP[settings.mode];
    $('failClosed').checked = settings.failClosed;
    $('failClosedRow').classList.toggle('disabled', settings.mode !== 'strict');
    $('failClosed').disabled = settings.mode !== 'strict';

    if (info && info.site) {
      const label = (NS.SITES[info.site] || {}).label || info.site;
      $('siteName').textContent = label;
      $('siteSwitch').hidden = false;
      $('siteEnabled').checked = settings.sites[info.site] !== false;
      let status;
      if (!settings.enabled) status = 'SpoilerShield is off';
      else if (settings.sites[info.site] === false) status = 'Off on this site';
      else if (info.shield === 'match') status = 'Page hidden (matched a keyword)';
      else if (info.shield) status = 'Page held: ' + info.shield;
      else status = info.mode === 'strict' ? 'Protected · strict' : 'Protected';
      if (info.pending) status += ' · ' + info.pending + ' held unverified';
      $('pageStatus').textContent = status;
      $('pageCount').textContent = info.pageCount;
    } else {
      $('siteName').textContent = 'This page';
      $('pageStatus').textContent = 'Not a supported site (or reload the tab)';
      $('pageCount').textContent = '–';
    }
  }

  async function save(mutator) {
    mutator(settings);
    settings = await NS.saveSettings(settings);
    render();
    refreshInfo();
  }

  async function refreshInfo() {
    if (!tab) return;
    await new Promise((r) => setTimeout(r, 150));
    try {
      info = await chrome.tabs.sendMessage(tab.id, { type: 'ss-page-info' });
    } catch (_) {
      /* ignore */
    }
    render();
  }

  $('enabled').addEventListener('change', (e) => save((s) => (s.enabled = e.target.checked)));
  $('siteEnabled').addEventListener('change', (e) => save((s) => (s.sites[info.site] = e.target.checked)));
  $('failClosed').addEventListener('change', (e) => save((s) => (s.failClosed = e.target.checked)));
  for (const b of document.querySelectorAll('[data-mode]')) {
    b.addEventListener('click', () => save((s) => (s.mode = b.dataset.mode)));
  }
  $('openOptions').addEventListener('click', () => chrome.runtime.openOptionsPage());

  const stats = await NS.loadStats();
  $('totalCount').textContent = stats.total;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[NS.STATS_KEY]) $('totalCount').textContent = (changes[NS.STATS_KEY].newValue || {}).total || 0;
  });

  render();
})();
