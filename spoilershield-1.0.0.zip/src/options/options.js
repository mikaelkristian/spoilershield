/* SpoilerShield — options page. */
(async function () {
  'use strict';
  const NS = globalThis.SpoilerShield;
  const $ = (id) => document.getElementById(id);
  const el = (tag, props, ...kids) => {
    const n = Object.assign(document.createElement(tag), props || {});
    for (const k of kids) n.append(k);
    return n;
  };

  let settings = await NS.loadSettings();
  const openDetails = new Set();

  async function save(mutator) {
    mutator(settings);
    settings = await NS.saveSettings(settings);
    render();
  }

  function switchEl(checked, label, onChange) {
    const input = el('input', { type: 'checkbox', checked });
    input.setAttribute('aria-label', label);
    input.addEventListener('change', () => onChange(input.checked));
    return el('label', { className: 'switch small' }, input, el('span', { className: 'track' }));
  }

  function renderSites() {
    const box = $('sites');
    box.replaceChildren();
    for (const [id, def] of Object.entries(NS.SITES)) {
      box.append(
        el('div', { className: 'site' }, el('span', { textContent: def.label }),
          switchEl(settings.sites[id] !== false, 'Enable on ' + def.label, (v) => save((s) => (s.sites[id] = v))))
      );
    }
  }

  function renderCategories() {
    const box = $('categories');
    box.replaceChildren();
    const disabled = new Set(settings.disabledKeywords.map((k) => k.toLowerCase()));
    for (const [cat, def] of Object.entries(NS.DEFAULT_CATEGORIES)) {
      const on = settings.categories[cat] !== false;
      const chips = el('div', { className: 'chips' });
      for (const kw of def.keywords) {
        const off = disabled.has(kw.toLowerCase());
        const btn = el('button', { type: 'button', textContent: off ? '+' : '×', title: off ? 'Re-enable' : 'Disable this keyword' });
        btn.setAttribute('aria-label', (off ? 'Re-enable ' : 'Disable ') + kw);
        btn.addEventListener('click', () =>
          save((s) => {
            const lower = kw.toLowerCase();
            s.disabledKeywords = off ? s.disabledKeywords.filter((k) => k.toLowerCase() !== lower) : s.disabledKeywords.concat(kw);
          })
        );
        chips.append(el('span', { className: 'chip' + (off ? ' disabled' : '') }, kw, btn));
      }
      const details = el('details', {}, el('summary', { textContent: 'Show ' + def.keywords.length + ' keywords (may contain spoilers)' }), chips);
      details.open = openDetails.has(cat);
      details.addEventListener('toggle', () => (details.open ? openDetails.add(cat) : openDetails.delete(cat)));
      box.append(
        el('div', { className: 'cat' },
          el('div', { className: 'row' },
            el('div', {}, el('div', { className: 'label', textContent: def.label }), el('div', { className: 'muted small', textContent: def.description })),
            switchEl(on, 'Enable ' + def.label, (v) => save((s) => (s.categories[cat] = v)))),
          details)
      );
    }
  }

  function renderCustom() {
    const box = $('custom');
    box.replaceChildren();
    for (const kw of settings.customKeywords) {
      const btn = el('button', { type: 'button', textContent: '×', title: 'Remove' });
      btn.setAttribute('aria-label', 'Remove ' + kw);
      btn.addEventListener('click', () => save((s) => (s.customKeywords = s.customKeywords.filter((k) => k !== kw))));
      box.append(el('span', { className: 'chip' }, kw, btn));
    }
    $('customEmpty').hidden = settings.customKeywords.length > 0;
  }

  async function renderStats() {
    const stats = await NS.loadStats();
    const box = $('stats');
    box.replaceChildren(el('div', {}, el('b', { textContent: stats.total }), el('span', { textContent: 'All sites' })));
    for (const [id, def] of Object.entries(NS.SITES)) {
      box.append(el('div', {}, el('b', { textContent: stats.bySite[id] || 0 }), el('span', { textContent: def.label })));
    }
  }

  function runTest() {
    const text = $('testInput').value;
    const out = $('testResult');
    if (!text.trim()) {
      out.textContent = '';
      out.className = 'small';
      return;
    }
    const matcher = NS.createMatcher(NS.activeKeywords(settings), { strict: settings.mode === 'strict' });
    const m = matcher.test(text);
    if (m) {
      const label = m.category === 'custom' ? 'your keywords' : NS.DEFAULT_CATEGORIES[m.category].label;
      out.textContent = 'Would be hidden: matches "' + m.keyword + '" (' + label + ').';
      out.className = 'small hit';
    } else {
      out.textContent = 'Would be shown (' + settings.mode + ' mode).';
      out.className = 'small miss';
    }
  }

  function render() {
    $('enabled').checked = settings.enabled;
    for (const b of document.querySelectorAll('[data-mode]')) b.setAttribute('aria-checked', String(b.dataset.mode === settings.mode));
    $('failClosed').checked = settings.failClosed;
    $('failClosed').disabled = settings.mode !== 'strict';
    $('failClosedRow').classList.toggle('disabled', settings.mode !== 'strict');
    renderSites();
    renderCategories();
    renderCustom();
    runTest();
  }

  $('enabled').addEventListener('change', (e) => save((s) => (s.enabled = e.target.checked)));
  $('failClosed').addEventListener('change', (e) => save((s) => (s.failClosed = e.target.checked)));
  for (const b of document.querySelectorAll('[data-mode]')) b.addEventListener('click', () => save((s) => (s.mode = b.dataset.mode)));
  $('addForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const words = $('newKeyword').value.split(',').map((w) => w.trim()).filter(Boolean);
    if (!words.length) return;
    $('newKeyword').value = '';
    save((s) => {
      const existing = new Set(s.customKeywords.map((k) => k.toLowerCase()));
      for (const w of words) if (!existing.has(w.toLowerCase())) s.customKeywords.push(w);
    });
  });
  $('testInput').addEventListener('input', runTest);
  $('resetStats').addEventListener('click', async () => {
    if (!confirm('Reset all blocked-item counts to zero?')) return;
    await chrome.storage.local.set({ [NS.STATS_KEY]: { total: 0, bySite: {} } });
    renderStats();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[NS.STATS_KEY]) renderStats();
    if (changes[NS.STORAGE_KEY]) {
      settings = NS.mergeSettings(changes[NS.STORAGE_KEY].newValue);
      render();
    }
  });

  render();
  renderStats();
})();
