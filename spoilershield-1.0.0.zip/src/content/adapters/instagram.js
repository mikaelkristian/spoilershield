/* SpoilerShield — Instagram adapter. */
(function (root) {
  'use strict';
  const NS = root.SpoilerShield;

  NS.registerAdapter({
    id: 'instagram',
    hosts: [/(^|\.)instagram\.com$/],
    items: [
      'article',
      // Grid tiles (explore, profiles, tag pages) — only those that wrap media, see acceptItem.
      'a[href*="/p/"]', 'a[href*="/reel/"]', 'a[href*="/reels/"]', 'a[href*="/tv/"]',
      // Search results / tag links
      'a[href^="/explore/tags/"]', 'a[href^="/explore/locations/"]',
      '[role="dialog"] article'
    ],
    // Instagram's comments, search results and reels viewer use obfuscated
    // class names; these structural selectors are used for loose-text matches.
    containers: ['ul > div', 'ul > li', '[role="dialog"] [role="button"]', 'div[role="presentation"] > div'],
    // Instagram's own alt text sometimes includes text it extracted from the image
    // ("May be an image of text that says ..."). We use that text; we do not analyse pixels.
    attrs: ['aria-label', 'alt', 'title'],
    acceptItem(el) {
      if (el.localName !== 'a') return true;
      const href = el.getAttribute('href') || '';
      if (href.startsWith('/explore/')) return true;
      // Post/reel links inside an article are timestamps etc.; the article is the item.
      if (el.closest('article')) return false;
      return !!el.querySelector('img, video, [style*="background-image"]');
    },
    pageText(loc, ctx, h) {
      const out = [];
      if (/^\/(p|reel|reels|tv)\//.test(loc.pathname)) out.push(h.text('article h1'), h.text('h1'));
      return out;
    },
    isSupportedPage(loc) {
      return /^\/($|explore|p\/|reel\/|reels\/|tv\/|stories\/|[A-Za-z0-9._]{1,30}\/?($|tagged|reels))/.test(loc.pathname);
    },
    neutralPage(loc) {
      return /^\/(accounts|direct|emails|challenge|privacy|legal|about)/.test(loc.pathname);
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
