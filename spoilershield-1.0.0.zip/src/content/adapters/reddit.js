/* SpoilerShield — Reddit adapter (new "shreddit" UI and old.reddit.com). */
(function (root) {
  'use strict';
  const NS = root.SpoilerShield;

  NS.registerAdapter({
    id: 'reddit',
    hosts: [/(^|\.)reddit\.com$/],
    items: [
      // New Reddit
      'shreddit-post', 'shreddit-ad-post', 'shreddit-comment', 'article',
      '[data-testid="search-post-unit"]', '[data-testid="search-sdui-post"]', '[data-testid="search-community"]',
      'search-telemetry-tracker', 'community-highlight-card',
      'reddit-recent-pages li', 'faceplate-tracker[noun="trending_search"]',
      // Old Reddit
      '.thing.link', '.thing.comment', '.search-result', '.trending-subreddits'
    ],
    containers: ['left-nav-community-item', 'faceplate-tracker', 'shreddit-subreddit-header', 'reddit-search-large li', '.side .md'],
    // shreddit-post exposes its title and subreddit as attributes.
    attrs: ['post-title', 'subreddit-prefixed-name', 'subreddit-name', 'author', 'content-href', 'permalink', 'aria-label', 'title'],
    hideTarget(el) {
      if (el.matches('shreddit-post, shreddit-ad-post')) return el.closest('article') || el;
      return el;
    },
    pageText(loc, ctx, h) {
      const out = [];
      if (/\/comments\//.test(loc.pathname)) {
        out.push(h.attr('shreddit-post', 'post-title'), h.text('shreddit-post h1, h1[slot="title"]'), h.text('.thing.link .title a.title'));
      }
      if (/^\/r\/[^/]+\/?$/.test(loc.pathname)) out.push(h.text('shreddit-subreddit-header'), h.text('.side .titlebox h1'));
      return out;
    },
    isSupportedPage(loc) {
      return /^\/($|r\/|user\/|u\/|search|best|hot|new|top|rising|popular|all|comments\/)/.test(loc.pathname);
    },
    neutralPage(loc) {
      return /^\/(settings|prefs|message\/compose|login|register|premium|coins)/.test(loc.pathname);
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
