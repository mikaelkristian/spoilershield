/* SpoilerShield — X / Twitter adapter. */
(function (root) {
  'use strict';
  const NS = root.SpoilerShield;

  NS.registerAdapter({
    id: 'x',
    hosts: [/(^|\.)x\.com$/, /(^|\.)twitter\.com$/],
    items: [
      '[data-testid="cellInnerDiv"]', 'article[data-testid="tweet"]', 'article[data-testid="notification"]',
      '[data-testid="trend"]', '[data-testid="UserCell"]', '[data-testid="typeaheadResult"]',
      '[data-testid="TypeaheadUser"]', '[data-testid="conversation"]'
    ],
    containers: ['[data-testid="placementTracking"]', '[role="link"]'],
    attrs: ['aria-label', 'title'],
    hideTarget(el) {
      // Hide the whole timeline row so no gap, avatar or "Show more" survives.
      if (!el.matches('[data-testid="cellInnerDiv"]')) {
        const cell = el.closest('[data-testid="cellInnerDiv"]');
        if (cell && el.matches('article, [data-testid="UserCell"], [data-testid="trend"]')) return cell;
      }
      return el;
    },
    pageText(loc, ctx, h) {
      const out = [];
      if (/\/status\/\d+/.test(loc.pathname)) {
        // The focused tweet on a status page.
        out.push(h.text('article[data-testid="tweet"][tabindex="-1"] [data-testid="tweetText"]'));
      }
      return out;
    },
    isSupportedPage(loc) {
      return /^\/($|home|explore|search|hashtag\/|notifications|i\/(bookmarks|lists|communities|trending)|[A-Za-z0-9_]{1,15}(\/|$))/.test(loc.pathname);
    },
    neutralPage(loc) {
      return /^\/(settings|i\/flow|i\/verified|i\/premium|compose|messages\/compose|logout|login)/.test(loc.pathname);
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
