/* SpoilerShield — Google Search and Google News adapter. */
(function (root) {
  'use strict';
  const NS = root.SpoilerShield;

  NS.registerAdapter({
    id: 'google',
    hosts: [/(^|\.)google\.[a-z.]{2,7}$/],
    items: [
      // Web results
      '#rso > div', '#rso div.g', 'div.MjjYud', '#botstuff div.MjjYud', 'div[data-hveid] > div.g',
      // Top stories, news, videos, carousels
      'g-section-with-header', 'g-inner-card', 'video-voyager', '.WlydOe', '.SoaBEf', 'div[data-news-cluster-id]',
      'block-component', 'g-scrolling-carousel g-inner-card',
      // People also ask, related searches, knowledge panel
      '.related-question-pair', 'div[jsname="Cpkphb"]', 'a.ngTNl', '.k8XOCe', '#rhs',
      // Image results
      'div[data-ri]', 'div[data-lpage]', 'div[jsname="dTDiAc"]',
      // Autocomplete suggestions
      'ul[role="listbox"] li', '.sbct',
      // Google News
      'c-wiz article', 'article'
    ],
    containers: ['[role="heading"]', 'g-link', 'a[href^="/search"]', 'div[data-attrid]'],
    attrs: ['aria-label', 'title', 'alt'],
    hideTarget(el) {
      // Hide the outermost result block so no empty wrapper or snippet survives.
      if (el.closest('#rso')) {
        const block = el.closest('div.MjjYud') || el.closest('#rso > div');
        if (block && el.matches('div.g, div.MjjYud, #rso > div, .WlydOe, .SoaBEf, video-voyager, block-component')) return block;
      }
      return el;
    },
    pageText(loc, ctx, h) {
      return [h.attr('textarea[name="q"], input[name="q"]', 'value')];
    },
    isSupportedPage(loc) {
      return /^\/($|search|webhp|imghp|stories|topics|home|foryou|articles|read)/.test(loc.pathname) || /^news\./.test(loc.hostname);
    },
    neutralPage(loc) {
      return loc.pathname === '/' || /^\/(webhp|imghp|preferences|setprefs|advanced_search|intl\/|account)/.test(loc.pathname);
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
