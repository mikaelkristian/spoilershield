/* SpoilerShield — YouTube adapter (www.youtube.com, m.youtube.com). */
(function (root) {
  'use strict';
  const NS = root.SpoilerShield;

  const VIDEO_CARDS = [
    // Desktop (Polymer / view-model components)
    'ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-compact-video-renderer', 'ytd-grid-video-renderer',
    'yt-lockup-view-model', 'ytd-reel-item-renderer', 'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2',
    'ytd-reel-video-renderer', 'ytd-playlist-renderer', 'ytd-compact-playlist-renderer', 'ytd-grid-playlist-renderer',
    'ytd-radio-renderer', 'ytd-compact-radio-renderer', 'ytd-channel-renderer', 'ytd-grid-channel-renderer',
    'ytd-movie-renderer', 'ytd-compact-movie-renderer', 'ytd-playlist-video-renderer', 'ytd-playlist-panel-video-renderer',
    'ytd-universal-watch-card-renderer', 'ytd-horizontal-card-renderer', 'ytd-search-refinement-card-renderer',
    'ytd-post-renderer', 'ytd-backstage-post-thread-renderer', 'ytd-notification-renderer',
    'ytd-promoted-video-renderer', 'ytd-ad-slot-renderer', 'ytd-video-preview',
    // Comments
    'ytd-comment-thread-renderer', 'ytd-comment-view-model', 'ytd-comment-renderer',
    // Live chat
    'yt-live-chat-text-message-renderer', 'yt-live-chat-paid-message-renderer',
    // Mobile web (m.youtube.com)
    'ytm-rich-item-renderer', 'ytm-video-with-context-renderer', 'ytm-compact-video-renderer', 'ytm-video-card-renderer',
    'ytm-reel-item-renderer', 'ytm-playlist-renderer', 'ytm-compact-playlist-renderer', 'ytm-channel-renderer',
    'ytm-comment-thread-renderer', 'ytm-comment-renderer', 'ytm-post-renderer', 'ytm-backstage-post-thread-renderer'
  ];

  NS.registerAdapter({
    id: 'youtube',
    hosts: [/(^|\.)youtube\.com$/],
    items: VIDEO_CARDS,
    containers: [
      'ytd-guide-entry-renderer', 'yt-chip-cloud-chip-renderer', 'ytd-rich-shelf-renderer',
      '.ytp-videowall-still', '.ytp-modern-videowall-still', '.ytp-ce-element',
      '.ytp-autonav-endscreen-upnext-container', '.ytp-suggestion-set', '.ytp-title'
    ],
    attrs: ['aria-label', 'title'],
    hideTarget(el) {
      // Hide the whole grid cell, not just the inner lockup.
      if (!el.matches('ytd-rich-item-renderer')) {
        const cell = el.closest('ytd-rich-item-renderer, ytm-rich-item-renderer');
        if (cell) return cell;
      }
      // A matching top-level comment hides its whole thread (replies included).
      if (el.matches('ytd-comment-view-model, ytd-comment-renderer, ytm-comment-renderer') &&
          !el.closest('#replies, ytd-comment-replies-renderer')) {
        const thread = el.closest('ytd-comment-thread-renderer, ytm-comment-thread-renderer');
        if (thread) return thread;
      }
      return el;
    },
    pageText(loc, ctx, h) {
      const out = [];
      if (loc.pathname === '/watch') {
        out.push(
          h.text('ytd-watch-metadata h1'),
          h.text('ytd-watch-metadata #owner #channel-name'),
          h.text('ytd-watch-metadata #description-inline-expander'),
          h.text('#above-the-fold #title'),
          h.text('.ytp-title-link'),
          // m.youtube.com
          h.text('ytm-slim-video-metadata-section-renderer'),
          h.text('.slim-video-information-title')
        );
      }
      if (/^\/(@|c\/|channel\/|user\/)/.test(loc.pathname)) {
        out.push(h.text('#page-header h1'), h.text('ytd-channel-name#channel-name'), h.text('yt-page-header-renderer h1'));
      }
      if (loc.pathname.startsWith('/playlist')) out.push(h.text('ytd-playlist-header-renderer h1, yt-page-header-renderer h1'));
      return out;
    },
    pageReady(loc, ctx) {
      // On desktop watch pages the player can start before the title renders.
      // Hold the page until the metadata for *this* video id is present.
      if (loc.pathname !== '/watch') return true;
      const doc = ctx.document;
      if (!doc.querySelector('ytd-app')) return true; // mobile or unknown layout: rely on title/URL
      const v = new URLSearchParams(loc.search).get('v');
      const flexy = doc.querySelector('ytd-watch-flexy');
      const h1 = doc.querySelector('ytd-watch-metadata h1');
      const hasTitle = !!(h1 && h1.textContent.trim());
      if (flexy && flexy.hasAttribute('video-id')) return hasTitle && flexy.getAttribute('video-id') === v;
      return hasTitle;
    },
    isSupportedPage(loc) {
      return /^\/($|watch|results|shorts\/|feed\/|@|c\/|channel\/|user\/|hashtag\/|playlist|gaming|live_chat)/.test(loc.pathname);
    },
    neutralPage(loc) {
      return /^\/(account|premium|reporthistory|paid_memberships|t\/|about|howyoutubeworks)/.test(loc.pathname);
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
