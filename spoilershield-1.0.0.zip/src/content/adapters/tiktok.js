/* SpoilerShield — TikTok adapter. */
(function (root) {
  'use strict';
  const NS = root.SpoilerShield;

  NS.registerAdapter({
    id: 'tiktok',
    hosts: [/(^|\.)tiktok\.com$/],
    items: [
      '[data-e2e="recommend-list-item-container"]', 'article[data-e2e]',
      '[data-e2e="search_top-item"]', '[data-e2e="search_video-item"]', '[data-e2e="search-user-container"]',
      '[data-e2e="user-post-item"]', '[data-e2e="user-liked-item"]', '[data-e2e="user-favorite-item"]',
      '[data-e2e="challenge-item"]', '[data-e2e="explore-item"]', '[data-e2e="music-item"]',
      '[data-e2e="search-transfer-guess-search-item"]', '[data-e2e="top-comment-item"]',
      '[id^="column-item-video-container"]', '[id^="grid-item-container"]',
      'div[class*="DivItemContainerV2"]', 'div[class*="DivItemContainerForSearch"]',
      'div[class*="DivCommentItemContainer"]', 'div[class*="DivCommentObjectWrapper"]',
      'div[class*="DivReplyContainer"] > div'
    ],
    containers: ['[data-e2e="nav-search"]', '[data-e2e="search-suggestion"]', 'a[href*="/tag/"]', 'a[href*="/video/"]'],
    attrs: ['aria-label', 'alt', 'title'],
    pageText(loc, ctx, h) {
      const out = [];
      if (/\/video\/\d+/.test(loc.pathname) || /\/photo\/\d+/.test(loc.pathname)) {
        out.push(h.text('[data-e2e="browse-video-desc"]'), h.text('[data-e2e="video-desc"]'), h.text('h1[data-e2e="browse-video-desc"]'));
      }
      if (loc.pathname.startsWith('/tag/')) out.push(h.text('[data-e2e="challenge-title"]'));
      return out;
    },
    isSupportedPage(loc) {
      return /^\/($|foryou|following|explore|search|tag\/|music\/|@[^/]+(\/(video|photo)\/\d+)?\/?$)/.test(loc.pathname);
    },
    neutralPage(loc) {
      return /^\/(setting|login|signup|legal|about|messages|coin|upload|tiktokstudio)/.test(loc.pathname);
    }
  });
})(typeof globalThis !== 'undefined' ? globalThis : self);
