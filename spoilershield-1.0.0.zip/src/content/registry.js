/*
 * SpoilerShield — site adapter registry.
 *
 * A site adapter describes, for one website, which DOM elements are whole
 * "items" (posts, cards, videos, comments, trends...) that should be hidden
 * as a unit, and which page-level signals (URL, title, headline) identify a
 * page that is itself about a blocked topic.
 *
 * Adapter fields (all optional except id/hosts/items):
 *   id            string, key used in settings.sites
 *   hosts         RegExp[] tested against location.hostname
 *   items         CSS selectors for whole items
 *   containers    extra CSS selectors used when loose text (outside any item)
 *                 matches, to pick a sensible block to hide
 *   attrs         extra attribute names whose values count as item text
 *   acceptItem    (el) => boolean, filter out false-positive item matches
 *   hideTarget    (item) => Element, the element actually hidden (e.g. the
 *                 timeline cell that wraps a tweet)
 *   pageText      (location, ctx, helpers) => string[] extra page signals
 *   pageReady     (location, ctx, helpers) => boolean; false while the page's
 *                 own metadata is still loading (page is held behind a
 *                 "checking" screen meanwhile)
 *   isSupportedPage (location) => boolean, page types the adapter understands
 *   neutralPage   (location) => boolean, pages without feeds (never fail-closed)
 */
(function (root) {
  'use strict';

  const NS = (root.SpoilerShield = root.SpoilerShield || {});
  const adapters = (NS.adapters = NS.adapters || []);

  const GENERIC_CONTAINERS = [
    'article', 'li', '[role="article"]', '[role="listitem"]', '[role="option"]', '[role="row"]', 'tr', 'figure'
  ];

  const QUERY_KEYS = ['q', 'query', 'search_query', 'keyword', 'k', 'tag', 'search', 'hashtag'];

  function safeDecode(s) {
    try {
      return decodeURIComponent(String(s).replace(/\+/g, ' '));
    } catch (_) {
      return String(s);
    }
  }

  /** Text helpers handed to adapters. */
  function makeHelpers(doc) {
    return {
      text(selector) {
        const el = doc.querySelector(selector);
        return el ? el.textContent || '' : '';
      },
      texts(selector, limit) {
        const out = [];
        for (const el of doc.querySelectorAll(selector)) {
          out.push(el.textContent || '');
          if (limit && out.length >= limit) break;
        }
        return out;
      },
      attr(selector, name) {
        const el = doc.querySelector(selector);
        return (el && el.getAttribute(name)) || '';
      }
    };
  }

  /** Page signals every adapter gets: decoded path, search params, real title. */
  function defaultPageText(loc, ctx) {
    const out = [safeDecode(loc.pathname)];
    try {
      const params = new URLSearchParams(loc.search);
      for (const key of QUERY_KEYS) {
        const v = params.get(key);
        if (v) out.push(v);
      }
    } catch (_) {
      /* ignore malformed query */
    }
    if (ctx && ctx.title) out.push(ctx.title);
    return out;
  }

  function registerAdapter(def) {
    if (!def || !def.id || !Array.isArray(def.hosts) || !Array.isArray(def.items)) {
      throw new Error('SpoilerShield: invalid adapter definition');
    }
    const adapter = {
      containers: [],
      attrs: [],
      acceptItem: () => true,
      hideTarget: (el) => el,
      pageText: () => [],
      pageReady: () => true,
      isSupportedPage: () => true,
      neutralPage: () => false,
      ...def
    };
    adapter.itemSelector = adapter.items.join(',');
    adapter.containerSelector = adapter.containers.concat(GENERIC_CONTAINERS).join(',');
    const existing = adapters.findIndex((a) => a.id === adapter.id);
    if (existing >= 0) adapters.splice(existing, 1, adapter);
    else adapters.push(adapter);
    return adapter;
  }

  function findAdapter(hostname) {
    return adapters.find((a) => a.hosts.some((re) => re.test(hostname))) || null;
  }

  NS.registerAdapter = registerAdapter;
  NS.findAdapter = findAdapter;
  NS.defaultPageText = defaultPageText;
  NS.makeHelpers = makeHelpers;
  NS.safeDecode = safeDecode;
  NS.GENERIC_CONTAINERS = GENERIC_CONTAINERS;
})(typeof globalThis !== 'undefined' ? globalThis : self);
