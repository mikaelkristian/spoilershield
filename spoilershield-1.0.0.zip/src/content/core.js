/*
 * SpoilerShield — content-script engine.
 *
 * Runs at document_start on supported sites. Flow:
 *   1. content.css keeps <body> invisible until settings have loaded
 *      (html lacks data-ss-state), so nothing can paint unchecked.
 *   2. Settings load from chrome.storage.local; the existing DOM is scanned,
 *      then data-ss-state is set and the page becomes visible.
 *   3. A MutationObserver re-checks every added/changed node. Observer
 *      callbacks run as microtasks, i.e. before the browser's next paint,
 *      so matching items are hidden before they are drawn.
 *
 * Two layers of detection:
 *   - Items: adapter selectors for whole posts/cards/comments. The whole
 *     item (text + aria-label/title/alt + link paths) is matched and the
 *     whole item is hidden with display:none.
 *   - Loose text: any other text that matches hides its nearest sensible
 *     block container (list item, article, small card...).
 * Plus a page-level shield when the page itself (URL, title, headline) matches.
 */
(function () {
  'use strict';

  const NS = globalThis.SpoilerShield;
  if (!NS || NS.__engineStarted) return;
  NS.__engineStarted = true;

  const doc = document;
  const html = doc.documentElement;
  const STATE_ATTR = 'data-ss-state';
  const STATUS_ATTR = 'data-ss';
  const HIDE_ATTR = 'data-ss-hide';
  const SHIELD_ATTR = 'data-ss-shield';
  const SHIELD_TITLE = 'Hidden by SpoilerShield';
  // Timings can be overridden by tests via SpoilerShield.testConfig.
  const CFG = Object.assign(
    {
      SETTLE_MS: 150, // strict: text must be stable this long before an item is shown
      MIN_VERIFY_CHARS: 12, // strict: items with less text than this stay hidden
      READY_TIMEOUT_MS: 4000, // normal: max time to hold a page whose metadata is loading
      HEALTH_DELAY_MS: 3000, // fail-closed: grace period before judging a page unrecognised
      SETTINGS_TIMEOUT_MS: 1500 // start with defaults if storage has not answered by then
    },
    NS.testConfig || {}
  );
  const { SETTLE_MS, MIN_VERIFY_CHARS, READY_TIMEOUT_MS, HEALTH_DELAY_MS, SETTINGS_TIMEOUT_MS } = CFG;
  const MAX_TEXT = 20000;
  const SKIP_TAGS = new Set(['script', 'style', 'noscript', 'template', 'textarea', 'input', 'select', 'svg', 'head', 'title', 'iframe']);
  const SKIP_TEXT_SELECTOR =
    'script,style,noscript,template,textarea,input,select,head,title,[contenteditable]:not([contenteditable="false"]),.ss-overlay';
  const STRUCTURAL = new Set(['html', 'body', 'main', 'header', 'footer', 'nav', 'aside', 'form']);
  const BASE_ATTRS = ['aria-label', 'title', 'alt'];

  const adapter = NS.findAdapter(location.hostname);
  if (!adapter) {
    html.setAttribute(STATE_ATTR, 'off');
    return;
  }
  const ITEM_SEL = adapter.itemSelector;
  const CONTAINER_SEL = adapter.containerSelector;
  const ATTRS = Array.from(new Set(BASE_ATTRS.concat(adapter.attrs)));
  const helpers = NS.makeHelpers(doc);

  // ---- state -------------------------------------------------------------
  let settings = null;
  let matcher = null;
  let active = false;
  let strict = false;
  let observer = null;
  let itemState = new WeakMap(); // item -> { text, status, target, match }
  let hiddenBy = new WeakMap(); // hidden target -> Set(items responsible)
  const fallbackItems = new Set(); // loose-text containers we are tracking
  const settleQueue = new Map(); // item -> { text, since }
  let settleTimer = null;
  let pageCount = 0;
  let unsentDelta = 0;
  let reportTimer = null;

  let pageTitle = doc.title || '';
  let lastUrl = location.href;
  let urlChangedAt = Date.now();
  let lastPageSig = null;
  let lastPageMatch = null;
  let revealedUrl = null;
  let shieldEl = null;
  let shieldReason = null;
  let healthFailed = false;
  let pageTimer = null;

  // ---- helpers -------------------------------------------------------------
  function now() {
    return Date.now();
  }

  function isOurs(node) {
    return node.nodeType === 1 && node.classList && node.classList.contains('ss-overlay');
  }

  function isItem(el) {
    if (!el || el.nodeType !== 1) return false;
    if (fallbackItems.has(el)) return true;
    try {
      return el.matches(ITEM_SEL) && adapter.acceptItem(el);
    } catch (_) {
      return false;
    }
  }

  function parentOf(node) {
    if (node.parentElement) return node.parentElement;
    const p = node.parentNode;
    return p && p.nodeType === 11 && p.host ? p.host : null; // cross open shadow roots
  }

  function closestItem(node) {
    let el = node.nodeType === 1 ? node : parentOf(node);
    while (el) {
      if (isItem(el)) return el;
      el = parentOf(el);
    }
    return null;
  }

  function hrefText(href) {
    try {
      const u = new URL(href, location.href);
      return NS.safeDecode(u.pathname) + (u.hostname !== location.hostname ? ' ' + u.hostname : '');
    } catch (_) {
      return '';
    }
  }

  /**
   * Gather an item's text: text nodes, selected attributes, link paths and
   * open shadow roots. Nested items are skipped (they are judged separately).
   * Returns both a separator-joined and a raw-joined form so that
   * <div>Lucia</div><div>2M views</div> and Luc<b>ia</b> are both caught.
   */
  function collectText(item) {
    const sep = [];
    const raw = [];
    let len = 0;
    let nested = false;
    let ownChars = 0;
    const stack = [item];
    while (stack.length && len < MAX_TEXT) {
      const node = stack.pop();
      if (node.nodeType === 3) {
        const t = node.data;
        if (t) {
          sep.push(t);
          raw.push(t);
          len += t.length;
          ownChars += t.trim().length;
        }
        continue;
      }
      if (node.nodeType === 1) {
        if (node !== item) {
          if (SKIP_TAGS.has(node.localName)) continue;
          if (isOurs(node)) continue;
          if (isItem(node)) {
            nested = true;
            continue;
          }
        }
        for (const a of ATTRS) {
          const v = node.getAttribute(a);
          if (v) {
            sep.push(v);
            len += v.length;
            ownChars += v.trim().length;
          }
        }
        if (node.localName === 'a') {
          const href = node.getAttribute('href');
          if (href) sep.push(hrefText(href));
        }
        if (node.shadowRoot) stack.push(node.shadowRoot);
      } else if (node.nodeType !== 11) {
        continue;
      }
      const kids = node.childNodes;
      for (let i = kids.length - 1; i >= 0; i--) stack.push(kids[i]);
    }
    return { text: sep.join(' \n ') + ' \n ' + raw.join(''), nested, ownChars };
  }

  // ---- hide / show -----------------------------------------------------------
  // Media we paused only temporarily (strict "pending" items, "checking" screen),
  // resumed once the content is verified clean.
  const pausedByUs = new Set();

  function pauseMedia(rootEl, opts) {
    if (!rootEl || !rootEl.querySelectorAll) return;
    const temporary = !!(opts && opts.temporary);
    for (const m of rootEl.querySelectorAll('video, audio')) {
      try {
        if (temporary) {
          if (!m.paused) pausedByUs.add(m);
        } else {
          pausedByUs.delete(m);
          m.muted = true;
        }
        m.pause();
      } catch (_) {
        /* ignore */
      }
    }
  }

  function resumeMedia(rootEl) {
    if (!pausedByUs.size) return;
    for (const m of Array.from(pausedByUs)) {
      if (!m.isConnected) {
        pausedByUs.delete(m);
        continue;
      }
      if (rootEl !== doc && !rootEl.contains(m)) continue;
      if (m.closest('[' + HIDE_ATTR + '], [' + STATUS_ATTR + '="pending"]')) continue;
      pausedByUs.delete(m);
      try {
        const p = m.play();
        if (p && p.catch) p.catch(() => {});
      } catch (_) {
        /* autoplay policy etc. */
      }
    }
  }

  function hideTarget(target, owner) {
    let owners = hiddenBy.get(target);
    if (!owners) hiddenBy.set(target, (owners = new Set()));
    const wasHidden = owners.size > 0;
    owners.add(owner);
    if (!target.hasAttribute(HIDE_ATTR)) target.setAttribute(HIDE_ATTR, '');
    if (!wasHidden) {
      pauseMedia(target);
      bumpCount();
    }
  }

  function releaseTarget(target, owner) {
    const owners = hiddenBy.get(target);
    if (!owners) return;
    owners.delete(owner);
    if (owners.size === 0) {
      hiddenBy.delete(target);
      target.removeAttribute(HIDE_ATTR);
    }
  }

  function setStatus(item, status, text, match) {
    const prev = itemState.get(item);
    if (item.getAttribute(STATUS_ATTR) !== status) item.setAttribute(STATUS_ATTR, status);
    let target = prev ? prev.target : null;
    if (status === 'match') {
      const t = adapter.hideTarget(item) || item;
      if (target && target !== t) releaseTarget(target, item);
      target = t;
      hideTarget(target, item);
    } else if (target) {
      releaseTarget(target, item);
      target = null;
    }
    if (status === 'pending') pauseMedia(item, { temporary: true });
    else if (status === 'ok' && prev && prev.status === 'pending') resumeMedia(item);
    itemState.set(item, { text, status, target, match: match || null });
  }

  function forget(item) {
    const st = itemState.get(item);
    if (st && st.target) releaseTarget(st.target, item);
    itemState.delete(item);
    settleQueue.delete(item);
    fallbackItems.delete(item);
  }

  // ---- item evaluation -----------------------------------------------------
  function evaluate(item) {
    if (!item.isConnected) {
      forget(item);
      return;
    }
    const { text, nested, ownChars } = collectText(item);
    const prev = itemState.get(item);
    if (prev && prev.text === text && prev.status !== 'pending') return;

    const match = matcher.test(text);
    if (match) {
      settleQueue.delete(item);
      setStatus(item, 'match', text, match);
      return;
    }
    if (strict && (!prev || prev.status !== 'ok')) {
      // Never shown yet: wait until the item's text stops changing.
      const q = settleQueue.get(item);
      const t = now();
      if (!q || q.text !== text) {
        settleQueue.set(item, { text, since: t });
        scheduleSettle();
        setStatus(item, 'pending', text);
        return;
      }
      if (t - q.since < SETTLE_MS) {
        scheduleSettle();
        setStatus(item, 'pending', text);
        return;
      }
      settleQueue.delete(item);
      if (!nested && ownChars < MIN_VERIFY_CHARS) {
        // Not enough text to inspect (e.g. an image-only tile): keep hidden.
        setStatus(item, 'pending', text);
        return;
      }
    }
    setStatus(item, 'ok', text);
  }

  function scheduleSettle() {
    if (settleTimer) return;
    settleTimer = setTimeout(() => {
      settleTimer = null;
      if (!active) return;
      for (const item of Array.from(settleQueue.keys())) safely(() => evaluate(item));
    }, SETTLE_MS + 10);
  }

  // ---- loose text (outside known items) ------------------------------------
  function textLength(el) {
    return (el.textContent || '').length;
  }

  function findContainer(el) {
    const c = el.closest(CONTAINER_SEL);
    if (c && !STRUCTURAL.has(c.localName) && textLength(c) < 6000) return c;
    let best = el;
    let cur = el;
    while (cur.parentElement && !STRUCTURAL.has(cur.parentElement.localName) && textLength(cur.parentElement) <= 600) {
      cur = cur.parentElement;
      best = cur;
    }
    return best;
  }

  function checkLooseElement(el) {
    if (!el || el.nodeType !== 1 || STRUCTURAL.has(el.localName)) return;
    if (el.closest(SKIP_TEXT_SELECTOR) || el.closest('[' + HIDE_ATTR + ']')) return;
    if (closestItem(el)) return; // covered by item evaluation
    let text = el.textContent || '';
    if (text.length > 3000) {
      text = Array.from(el.childNodes)
        .filter((n) => n.nodeType === 3)
        .map((n) => n.data)
        .join(' ');
    }
    let match = matcher.test(text);
    const parent = el.parentElement;
    if (!match && parent && !STRUCTURAL.has(parent.localName) && textLength(parent) < 400) {
      match = matcher.test(parent.textContent);
    }
    if (!match) return;
    const container = findContainer(el);
    if (STRUCTURAL.has(container.localName)) return;
    fallbackItems.add(container);
    evaluate(container);
  }

  function scanLoose(rootNode) {
    if (rootNode.nodeType === 3) {
      if (rootNode.data.trim()) checkLooseElement(rootNode.parentElement);
      return;
    }
    if (rootNode.nodeType !== 1 || isOurs(rootNode)) return;
    if (rootNode.closest('head')) return;
    const parents = new Set();
    const walker = doc.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (n.data.trim() && n.parentElement) parents.add(n.parentElement);
    }
    for (const p of parents) checkLooseElement(p);
  }

  // ---- scanning ---------------------------------------------------------------
  function safely(fn) {
    try {
      fn();
    } catch (e) {
      if (NS.debug) console.warn('[SpoilerShield]', e);
    }
  }

  function itemsWithin(rootEl, out) {
    if (isItem(rootEl)) out.add(rootEl);
    if (rootEl.querySelectorAll) {
      for (const el of rootEl.querySelectorAll(ITEM_SEL)) if (adapter.acceptItem(el)) out.add(el);
    }
  }

  function fullScan() {
    const items = new Set();
    itemsWithin(html, items);
    for (const it of items) safely(() => evaluate(it));
    if (doc.body) safely(() => scanLoose(doc.body));
    checkPage();
  }

  function onMutations(records) {
    if (!active) return;
    const items = new Set();
    const roots = [];
    let titleChanged = false;
    for (const r of records) {
      const target = r.target;
      if (target === html && r.type === 'attributes') {
        if (r.attributeName === STATE_ATTR && html.getAttribute(STATE_ATTR) !== stateValue()) html.setAttribute(STATE_ATTR, stateValue());
        continue;
      }
      if (isInTitle(target)) {
        titleChanged = true;
        continue;
      }
      if (r.type === 'childList') {
        for (const n of r.addedNodes) {
          if (n.nodeType === 1 && !isOurs(n)) roots.push(n);
          else if (n.nodeType === 3) roots.push(n);
        }
      } else if (r.type === 'characterData') {
        roots.push(target);
      }
      const it = closestItem(target);
      if (it) items.add(it);
    }
    for (const root of roots) if (root.nodeType === 1) safely(() => itemsWithin(root, items));
    for (const it of items) safely(() => evaluate(it));
    for (const root of roots) safely(() => scanLoose(root));
    if (titleChanged) onTitleChanged();
    if (shieldEl && shieldReason && !shieldEl.isConnected) html.appendChild(shieldEl);
    checkPage();
  }

  function isInTitle(node) {
    const el = node.nodeType === 1 ? node : node.parentNode;
    return !!(el && el.nodeType === 1 && (el.localName === 'title' || (el.closest && el.closest('title'))));
  }

  function startObserver() {
    if (observer) return;
    observer = new MutationObserver(onMutations);
    observer.observe(html, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: Array.from(new Set(ATTRS.concat(['href', STATE_ATTR])))
    });
  }

  function stopObserver() {
    if (observer) observer.disconnect();
    observer = null;
  }

  // ---- page-level shield ----------------------------------------------------
  function onTitleChanged() {
    const t = doc.title;
    if (t !== SHIELD_TITLE) {
      pageTitle = t;
      if (shieldReason) doc.title = SHIELD_TITLE;
    }
  }

  function onUrlChange() {
    lastUrl = location.href;
    urlChangedAt = now();
    revealedUrl = null;
    healthFailed = false;
    lastPageSig = null;
    schedulePageCheck(READY_TIMEOUT_MS + 50);
    schedulePageCheck(HEALTH_DELAY_MS + 50);
    // SPA navigations often recycle elements: re-verify everything.
    if (active) {
      const items = new Set();
      itemsWithin(html, items);
      for (const it of items) safely(() => evaluate(it));
    }
  }

  function schedulePageCheck(delay) {
    setTimeout(() => safely(checkPage), delay);
  }

  function computeShieldReason() {
    const ctx = { title: pageTitle, document: doc, strict };
    const parts = NS.defaultPageText(location, ctx).concat(adapter.pageText(location, ctx, helpers) || []);
    const sig = parts.filter(Boolean).join(' \n ');
    if (sig !== lastPageSig) {
      lastPageSig = sig;
      lastPageMatch = matcher.test(sig);
    }
    if (lastPageMatch) return { kind: 'match', category: lastPageMatch.category };

    const age = now() - urlChangedAt;
    if (!adapter.pageReady(location, ctx, helpers)) {
      if (age < READY_TIMEOUT_MS) return { kind: 'checking' };
      if (strict) return { kind: 'unverified' };
    }
    if (strict && settings.failClosed && !adapter.neutralPage(location)) {
      if (!adapter.isSupportedPage(location)) return { kind: 'unsupported' };
      if (age >= HEALTH_DELAY_MS) {
        const hasItems = !!doc.querySelector(ITEM_SEL);
        healthFailed = !hasItems && !!doc.body && textLength(doc.body) > 300;
        if (healthFailed) return { kind: 'unrecognized' };
      }
    }
    return null;
  }

  function checkPage() {
    if (!active) return;
    if (location.href !== lastUrl) onUrlChange();
    const reason = computeShieldReason();
    if (reason && revealedUrl !== location.href) showShield(reason);
    else hideShield();
  }

  const CATEGORY_LABELS = { custom: 'your custom keywords' };
  function categoryLabel(cat) {
    if (CATEGORY_LABELS[cat]) return CATEGORY_LABELS[cat];
    const def = NS.DEFAULT_CATEGORIES[cat];
    return def ? '"' + def.label + '"' : 'a blocked keyword';
  }

  function shieldCopy(reason) {
    switch (reason.kind) {
      case 'match':
        return ['This page is hidden', 'It matched ' + categoryLabel(reason.category) + '. The keyword itself is not shown, in case it is a spoiler.'];
      case 'checking':
        return ['Checking this page…', 'Waiting for the title to load before showing anything.'];
      case 'unverified':
        return ['Could not verify this page', 'Strict mode: the page title never loaded, so it stays hidden.'];
      case 'unsupported':
        return ['Unsupported page hidden', 'Strict fail-closed mode: SpoilerShield does not know how to scan this kind of page.'];
      case 'unrecognized':
        return ['Feed not recognised', 'Strict fail-closed mode: no known posts or cards were found here (the site layout may have changed), so the page is hidden.'];
      default:
        return ['Hidden', ''];
    }
  }

  function buildShield() {
    const el = doc.createElement('div');
    el.className = 'ss-overlay';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    const card = doc.createElement('div');
    card.className = 'ss-card';
    const brand = doc.createElement('div');
    brand.className = 'ss-brand';
    brand.textContent = 'SpoilerShield';
    const h = doc.createElement('div');
    h.className = 'ss-title';
    const p = doc.createElement('div');
    p.className = 'ss-text';
    const row = doc.createElement('div');
    row.className = 'ss-actions';
    const back = doc.createElement('button');
    back.className = 'ss-btn ss-primary';
    back.textContent = 'Go back';
    back.addEventListener('click', () => {
      if (history.length > 1) history.back();
      else location.href = location.origin + '/';
    });
    const reveal = doc.createElement('button');
    reveal.className = 'ss-btn';
    reveal.textContent = 'Show this page anyway';
    reveal.addEventListener('click', () => {
      if (reveal.dataset.confirm !== '1') {
        reveal.dataset.confirm = '1';
        reveal.textContent = 'Click again to reveal (spoilers possible)';
        return;
      }
      revealedUrl = location.href;
      hideShield();
    });
    row.append(back, reveal);
    card.append(brand, h, p, row);
    el.append(card);
    el._ss = { h, p, reveal };
    return el;
  }

  function showShield(reason) {
    if (!shieldEl) shieldEl = buildShield();
    const key = reason.kind + ':' + (reason.category || '');
    if (!shieldReason || shieldReason.key !== key) {
      const [title, text] = shieldCopy(reason);
      shieldEl._ss.h.textContent = title;
      shieldEl._ss.p.textContent = text;
      shieldEl._ss.reveal.dataset.confirm = '';
      shieldEl._ss.reveal.textContent = 'Show this page anyway';
      shieldEl._ss.reveal.hidden = reason.kind === 'checking';
      if (!shieldReason && reason.kind === 'match') bumpCount();
    }
    shieldReason = { ...reason, key };
    if (!shieldEl.isConnected) html.appendChild(shieldEl);
    if (html.getAttribute(SHIELD_ATTR) !== reason.kind) html.setAttribute(SHIELD_ATTR, reason.kind);
    if (doc.title !== SHIELD_TITLE) doc.title = SHIELD_TITLE;
    pauseMedia(doc, { temporary: reason.kind === 'checking' });
  }

  function hideShield() {
    if (!shieldReason) return;
    const wasChecking = shieldReason.kind === 'checking';
    shieldReason = null;
    if (shieldEl && shieldEl.isConnected) shieldEl.remove();
    html.removeAttribute(SHIELD_ATTR);
    if (doc.title === SHIELD_TITLE) doc.title = pageTitle;
    if (wasChecking) resumeMedia(doc);
  }

  // Keep media paused while it is hidden (autoplaying reels/shorts, previews).
  doc.addEventListener(
    'play',
    (e) => {
      if (!active) return;
      const t = e.target;
      if (shieldReason || (t.closest && t.closest('[' + HIDE_ATTR + '], [' + STATUS_ATTR + '="pending"]'))) {
        const temporary = shieldReason ? shieldReason.kind === 'checking' : !t.closest('[' + HIDE_ATTR + ']');
        safely(() => {
          if (temporary) pausedByUs.add(t);
          t.pause();
        });
      }
    },
    true
  );

  // ---- counting ------------------------------------------------------------
  function bumpCount() {
    pageCount++;
    unsentDelta++;
    if (!reportTimer) reportTimer = setTimeout(report, 500);
  }

  // Flush counts when the page is left, so quick navigations are still counted.
  window.addEventListener('pagehide', () => {
    if (unsentDelta) report();
  });

  function report() {
    if (reportTimer) clearTimeout(reportTimer);
    reportTimer = null;
    const delta = unsentDelta;
    unsentDelta = 0;
    try {
      const p = chrome.runtime.sendMessage({ type: 'ss-count', pageCount, delta, site: adapter.id });
      if (p && p.catch) p.catch(() => {});
    } catch (_) {
      /* extension reloaded or unavailable */
    }
  }

  // ---- settings --------------------------------------------------------------
  function stateValue() {
    return active ? (strict ? 'strict' : 'normal') : 'off';
  }

  function resetMarks() {
    for (const el of doc.querySelectorAll('[' + STATUS_ATTR + '], [' + HIDE_ATTR + ']')) {
      el.removeAttribute(STATUS_ATTR);
      el.removeAttribute(HIDE_ATTR);
    }
    itemState = new WeakMap();
    hiddenBy = new WeakMap();
    fallbackItems.clear();
    settleQueue.clear();
    lastPageSig = null;
  }

  function applySettings(raw) {
    settings = NS.mergeSettings(raw);
    const siteOn = settings.enabled && settings.sites[adapter.id] !== false;
    stopObserver();
    resetMarks();
    if (!siteOn) {
      active = false;
      hideShield();
      html.setAttribute(STATE_ATTR, 'off');
      return;
    }
    strict = settings.mode === 'strict';
    matcher = NS.createMatcher(NS.activeKeywords(settings), { strict });
    active = true;
    fullScan(); // before revealing the page
    html.setAttribute(STATE_ATTR, stateValue());
    startObserver();
  }

  // ---- messaging (popup) -----------------------------------------------------
  try {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg || msg.type !== 'ss-page-info') return;
      sendResponse({
        site: adapter.id,
        active,
        mode: strict ? 'strict' : 'normal',
        pageCount,
        pending: doc.querySelectorAll('[' + STATUS_ATTR + '="pending"]').length,
        shield: shieldReason ? shieldReason.kind : null
      });
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[NS.STORAGE_KEY]) safely(() => applySettings(changes[NS.STORAGE_KEY].newValue));
    });
  } catch (_) {
    /* not running as an extension (tests) */
  }

  // ---- URL change detection for single-page apps -----------------------------
  const urlCheck = () => {
    if (location.href !== lastUrl) safely(checkPage);
  };
  let ticks = 0;
  setInterval(() => {
    urlCheck();
    if (++ticks % 30 === 0) {
      // Drop tracked loose-text containers that left the page.
      for (const el of Array.from(fallbackItems)) if (!el.isConnected) forget(el);
    }
  }, 300);
  window.addEventListener('popstate', urlCheck);
  window.addEventListener('hashchange', urlCheck);
  doc.addEventListener('yt-navigate-finish', urlCheck);
  try {
    if (window.navigation) window.navigation.addEventListener('navigatesuccess', urlCheck);
  } catch (_) {
    /* Navigation API unavailable */
  }
  doc.addEventListener('DOMContentLoaded', () => {
    if (!pageTitle) pageTitle = doc.title;
    safely(checkPage);
  });

  // ---- boot --------------------------------------------------------------------
  let booted = false;
  function boot(raw) {
    if (booted) return;
    booted = true;
    safely(() => applySettings(raw));
    if (!html.hasAttribute(STATE_ATTR)) html.setAttribute(STATE_ATTR, 'normal'); // never leave the page blank
  }
  // If storage is unexpectedly slow, start with defaults (protection ON).
  setTimeout(() => boot(null), SETTINGS_TIMEOUT_MS);
  try {
    chrome.storage.local.get(NS.STORAGE_KEY).then(
      (data) => boot(data && data[NS.STORAGE_KEY]),
      () => boot(null)
    );
  } catch (_) {
    boot(null);
  }

  NS.__engine = {
    get pageCount() {
      return pageCount;
    },
    get shield() {
      return shieldReason;
    },
    rescan: () => safely(fullScan),
    applySettings
  };
})();
